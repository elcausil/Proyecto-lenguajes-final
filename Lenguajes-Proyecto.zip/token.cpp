#include "tokens.h"
#include <iterator>

using namespace std;

tokens::tokens()
{

}
void tokens::verificar(string phrase){
    int contadorVerbos = 0;
    int contadorSujetos = 0;
    ifstream archivo("verbos.txt");
    int i = 0;
    int contador = 0;
    string linea;
    string liniia;
    vector<string> word;
    while(getline(archivo, liniia)){
        contador++;
    }
    printf("He pasado por el while\n");
    while(i < contador){
        word.push_back(linea);
        i++;
    }
    printf("He agregado los vectores");
    int j = 0;
    size_t buscador;
    for(auto iterator = word.begin(); iterator!=word.end(); ++iterator){
        printf("holaaan\n");
        while(j < phrase.length()){
          printf("estoy en el primer while del for\n");
            buscador = phrase.find(word[j]);
            j++;  
            if (buscador!=string::npos){ // 34902032032
              printf("He empezado a contar los verbos\n");
              contadorVerbos++;
            }
        }
        if(contadorVerbos == 0 || contadorVerbos > 1){
            printf("holi gordaaa\n");
            system("pause");
        }
    }
}



