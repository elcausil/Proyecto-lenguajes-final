#include <iostream>
#include "token.h"

using namespace std;

int main(int argc, char* argv[]){
    int contador = 0;
    int i = 0;
    tokens tok("Juan jugea futbol");
    contador = Retificar(tok.getSujeto()) + contador;
    contador = Retificar(tok.getVerbo()) + contador;
    contador = Retificar(tok.getPredicado()) + contador;
    i = Comprobar(tok.getSujeto()) + i;
    i = Comprobar(tok.getVerbo()) + i;
    if (contador > 2){
        cout << "Oración Invalida" << endl;
    }
    else{if (i > 1){
            cout << "Oración Invalida" << endl;
    }
        else{
            cout << "Oración Valida" << endl;
        }
    }

    cout << "Sujeto: " << tok.getSujeto() << endl;
    cout << "Verbo: " << tok.getVerbo() << endl;

    return 0;
}