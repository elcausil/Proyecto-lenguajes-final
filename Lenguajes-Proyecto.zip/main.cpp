#include <iostream>
#include <string>
#include <fstream>
#include "tokens.h"

using namespace std;

int main() {
  string palabrita;
  cin >> palabrita;
  tokens obj = tokens();
  obj.verificar(palabrita);
  
}